package com.himanshu.coding.feb13;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello Feb 13th");
    }
}
