package com.himanshu.coding.june6;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }
}
