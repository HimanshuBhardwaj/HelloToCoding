package com.himanshu.coding.march19;

public class CountStringChars {
    public static void main(String[] args) {
        String str1 = "PvwYqzLhZvOtCWOiZ9SQwl3585TWJ7HgmpXTQlciD8GHnHmDEdoImGfCTbG1dyEM0JfKYsE2x8d6LWywif1QfQ==";
        String str2 = "HimanshuBhardwajHimanshuBhardwajHimanshuBhardwajHimanshuBhardwajHimanshuBhardwajhibhar==";
        System.out.println(str1.length());
        System.out.println(str2.length());
    }
}
