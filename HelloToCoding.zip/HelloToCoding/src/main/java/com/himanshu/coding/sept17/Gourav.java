package com.himanshu.coding.sept17;

public class Gourav {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
